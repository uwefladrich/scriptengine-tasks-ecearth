# EC-Earth 4 Monitoring Test Data

This repository contains test data for the [EC-Earth 4 monitoring tasks](https://github.com/uwefladrich/scriptengine-tasks-ecearth).

It is used for the automatic tests with Travis CI and can be used for running pytest after installing the package.
